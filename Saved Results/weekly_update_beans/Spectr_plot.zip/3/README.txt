Ho provato a fare varie visualizzazioni degli spettri. Qua c'è una breve descrizione.

V1: Una figura per ogni giorno. In ogni giorno ci sono 4 plot, 1 per lamp power, dove vengono visualizzate media e std dei gruppi di piante.
V2: Una figura per ogni giorno. In ogni giorno ci sono 3 plot, 1 per ogni tipo di pianta, dove vengono visualizzate media e std per le varie lamp power
V3: Una figura per ogni lamp power. Su figura ci sono 3 plot, 1 per ogni tipo di pianta, dove vengono visualizzati media e std per i vari giorni.

Poi sono separati i base al mems


